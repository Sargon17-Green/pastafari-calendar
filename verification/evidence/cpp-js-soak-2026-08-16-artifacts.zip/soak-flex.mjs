import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { performance } from 'node:perf_hooks';
import { PastafariCalendar } from './pastafari-calendar-fast.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const run = String(process.argv[2]);
const shard = Number(process.argv[3]);
const seedText = process.argv[4];
const stratum = process.argv[5];
const count = Number(process.argv[6]);
const radius = BigInt(process.argv[7]);
if (!run || !Number.isInteger(shard) || !seedText || !stratum || !Number.isInteger(count)) throw new Error('bad args');

const MASK=(1n<<64n)-1n; let state=BigInt(seedText)&MASK;
function next(){state=(state+0x9E3779B97F4A7C15n)&MASK;let z=state;z=((z^(z>>30n))*0xBF58476D1CE4E5B9n)&MASK;z=((z^(z>>27n))*0x94D049BB133111EBn)&MASK;return(z^(z>>31n))&MASK;}
function below(n){return next()%BigInt(n)}
function signed(r){r=BigInt(r);return below(2n*r+1n)-r}
const PRESENT=2461265n, FOUNDATION=-13334246n, YEARZERO=1721119n;
let c;
switch(stratum){
  case 'present': c=PRESENT+signed(365243); break;
  case 'present-far': c=PRESENT+signed(3652425); break;
  case 'foundation': c=FOUNDATION+signed(365243); break;
  case 'yearzero': c=YEARZERO+signed(365243); break;
  default: throw new Error(`stratum ${stratum}`);
}
const edge=[0n,1n,-1n,41n,-41n,42n,-42n,43n,-43n,962n,-962n,963n,-963n,964n,-964n,5777n,-5777n,5778n,-5778n,5779n,-5779n];
const cases=[];
for(let i=0;i<count;i++){
  let t;
  if(i<edge.length) t=c+edge[i];
  else if(Number(below(100n))<3) t=c+edge[Number(below(BigInt(edge.length)))];
  else t=c+signed(radius);
  cases.push({c,t});
}
const input=cases.map(x=>`${x.c} ${x.t}`).join('\n')+'\n';
const t0=performance.now();
const cpp=spawnSync(resolve(here,'cpp-batch'),[],{input,encoding:'utf8',maxBuffer:256*1024*1024});
const cppSeconds=(performance.now()-t0)/1000;
if(cpp.error) throw cpp.error; if(cpp.status!==0) throw new Error(cpp.stderr||`cpp ${cpp.status}`);
const lines=cpp.stdout.trim().split(/\r?\n/); if(lines.length!==cases.length) throw new Error(`lines ${lines.length}`);
const cal=new PastafariCalendar();
let firstFailure=null;
const j0=performance.now();
for(let i=0;i<cases.length;i++){
  const {c,t}=cases[i]; const p=lines[i].split('\t');
  const a=JSON.parse(p.slice(2).join('\t')); const r=cal.convertJdn(t,{calculationJdn:c}); const b=r.toJSON?.()??r;
  if(JSON.stringify(a)!==JSON.stringify(b)){firstFailure={index:i,calculationJdn:String(c),targetJdn:String(t),cpp:a,js:b};break;}
}
const jsSeconds=(performance.now()-j0)/1000;
const s={run,shard,seed:seedText,stratum,calculationJdn:String(c),countPlanned:count,countCompared:firstFailure?firstFailure.index+1:count,radiusDays:String(radius),failures:firstFailure?1:0,firstFailure,cppSeconds,jsSeconds,passed:!firstFailure};
writeFileSync(resolve(here,`summary-${run}-${shard}.json`),JSON.stringify(s,null,2)+'\n');
console.log(JSON.stringify(s));
process.exit(firstFailure?1:0);
